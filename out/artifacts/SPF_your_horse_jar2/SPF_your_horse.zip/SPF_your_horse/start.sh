#!/bin/bash
java --module-path javafx-sdk-15.0.1/lib --add-modules javafx.controls,javafx.fxml,javafx.graphics,javafx.web -jar SPF_your_horse.jar
